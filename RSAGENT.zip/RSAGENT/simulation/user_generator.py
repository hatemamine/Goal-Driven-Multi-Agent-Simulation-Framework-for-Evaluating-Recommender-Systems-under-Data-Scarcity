import os
import random
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from llm import generate

_ROLES = [
    "محامٍ متخصص في القانون التجاري",
    "قاضٍ متخصص في القانون الجنائي",
    "طالب دكتوراه في القانون الدستوري",
    "موثق (نوتير) يعمل في مجال العقود العقارية",
    "مستشار قانوني في مؤسسة عمومية",
    "أستاذ جامعي في القانون الإداري",
    "محامٍ متخصص في قانون الأسرة والميراث",
    "مفتش عمل في وزارة العمل",
    "محامٍ متخصص في قانون العمل والضمان الاجتماعي",
    "باحث في مجال حقوق الإنسان والقانون الدولي",
]

_SCHEMA = {
    "type": "object",
    "properties": {
        "goal": {
            "type": "string",
            "description": "Specific legal research goal in Arabic",
        },
        "plan": {
            "type": "array",
            "items": {"type": "string"},
            "description": "3 to 5 ordered search steps in Arabic",
        },
        "expertise_level": {
            "type": "string",
            "enum": ["novice", "intermediate", "expert"],
        },
        "starting_query": {
            "type": "string",
            "description": "Random, slightly off-target Arabic query to start search",
        },
    },
    "required": ["goal", "plan", "expertise_level", "starting_query"],
}


def _generate_one(user_id: str, role: str) -> dict:
    prompt = (
        f"أنت تنشئ ملفاً لمستخدم افتراضي لنظام استرجاع المعلومات القانونية الجزائرية.\n\n"
        f"المستخدم: {role}\n\n"
        "أنشئ باللغة العربية:\n"
        "1. goal: هدف بحثي محدد وواقعي يناسب هذا الدور في القانون الجزائري.\n"
        "2. plan: قائمة من 3 إلى 5 خطوات بحث مرتبة لتحقيق الهدف.\n"
        "3. expertise_level: مستوى الخبرة (novice أو intermediate أو expert).\n"
        "4. starting_query: استعلام أولي عشوائي — مرتبط بالمجال لكن غير مصاغ مباشرة "
        "كالهدف، ليحاكي مستخدماً حقيقياً يبدأ من نقطة غير دقيقة.\n\n"
        "القانون الجزائري يشمل: التجاري، الجنائي، المدني، الإداري، الأسرة، العمل، الدستوري، العقاري."
    )
    profile = generate(prompt, _SCHEMA)
    return {"user_id": user_id, "role": role, **profile}


def generate_users(n: int, roles: list[str] | None = None) -> list[dict]:
    pool = roles if roles else _ROLES
    selected = (pool * ((n // len(pool)) + 1))[:n]
    random.shuffle(selected)

    users = []
    for i, role in enumerate(selected):
        user_id = f"user_{i + 1:03d}"
        print(f"Generating {user_id}: {role}")
        users.append(_generate_one(user_id, role))
    return users
