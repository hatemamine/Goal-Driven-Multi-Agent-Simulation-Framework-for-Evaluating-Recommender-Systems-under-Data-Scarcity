"""
Goal-driven search agent using a local Gemma model via Ollama.

Each agent has a goal, a plan, and a random starting query.
At every iteration it:
  1. Searches the IR API with the current query.
  2. Asks Gemma to judge each new document and decide the next query.
  3. Stops when the goal is complete, no new docs exist, or max_iterations reached.

Returns a flat list of interaction dicts — the caller handles DB persistence.
"""

import json
import os
import sys
from datetime import datetime

import requests

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from llm import generate

_DECISION_SCHEMA = {
    "type": "object",
    "properties": {
        "doc_judgments": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "doc_id":    {"type": "string"},
                    "relevance": {"type": "integer"},
                },
                "required": ["doc_id", "relevance"],
            },
        },
        "goal_progress": {
            "type": "string",
            "enum": ["none", "partial", "complete"],
        },
        "reasoning": {"type": "string"},
        "next_query": {"type": "string"},
        "stop":       {"type": "boolean"},
    },
    "required": ["doc_judgments", "goal_progress", "reasoning", "next_query", "stop"],
}


def _search_ir(base_url: str, query: str, top_k: int) -> list[dict]:
    r = requests.get(
        f"{base_url}/search",
        params={"query": query, "top_k": top_k},
        timeout=30,
    )
    r.raise_for_status()
    return r.json()["results"]


def _build_prompt(user: dict, iteration: int, history: list[dict], docs: list[dict]) -> str:
    plan = user["plan"] if isinstance(user["plan"], list) else json.loads(user["plan"])
    plan_str = "\n".join(f"  {i+1}. {step}" for i, step in enumerate(plan))

    history_str = ""
    if history:
        history_str = "\nالتاريخ:\n" + "\n".join(
            f"  - الاستعلام «{h['query']}» → وجدت {h['relevant_count']} وثيقة ملائمة"
            for h in history
        )

    docs_str = "\n\n".join(
        f"[doc_id={d['id']}]\n{d['text'][:500]}" for d in docs
    )

    return (
        f"أنت عميل بحثي يعمل على تحقيق هدف قانوني جزائري.\n\n"
        f"الهوية: {user['role']}\n"
        f"مستوى الخبرة: {user['expertise_level']}\n\n"
        f"الهدف: {user['goal']}\n\n"
        f"الخطة:\n{plan_str}\n"
        f"{history_str}\n\n"
        f"الاستعلام الحالي (التكرار {iteration}): «{docs[0].get('_query', '')}»\n\n"
        f"الوثائق المسترجعة:\n\n{docs_str}\n\n"
        "المطلوب:\n"
        "1. doc_judgments: قيّم كل وثيقة — relevance: 0 (غير ملائمة) أو 1 (ملائمة نوعاً ما) أو 2 (ملائمة جداً).\n"
        "2. goal_progress: none أو partial أو complete.\n"
        "3. reasoning: شرح موجز لتقييمك.\n"
        "4. next_query: الاستعلام العربي التالي لتحسين البحث.\n"
        "5. stop: true إذا اكتمل الهدف أو لا يوجد ما تبحث عنه، وإلا false."
    )


def run_agent(
    user: dict,
    ir_base_url: str = "http://127.0.0.1:8000",
    max_iterations: int = 6,
    ir_top_k: int = 10,
) -> list[dict]:
    """
    Run one goal-driven agent session.
    Returns a list of interaction dicts ready for sim_db.insert_interactions().
    """
    current_query = user["starting_query"]
    seen_ids: set[str] = set()
    history: list[dict] = []
    all_interactions: list[dict] = []

    for iteration in range(1, max_iterations + 1):
        print(f"  [{user['user_id']}] iter={iteration}  query=«{current_query}»")

        docs = _search_ir(ir_base_url, current_query, ir_top_k)
        for d in docs:
            d["_query"] = current_query

        new_docs = [d for d in docs if d["id"] not in seen_ids]
        if not new_docs:
            print(f"  [{user['user_id']}] No new documents — stopping.")
            break

        prompt = _build_prompt(user, iteration, history, new_docs)
        decision = generate(prompt, _DECISION_SCHEMA)

        # Clamp relevance to 0/1/2 in case the model drifts
        judgment_map = {
            j["doc_id"]: max(0, min(2, int(j["relevance"])))
            for j in decision.get("doc_judgments", [])
        }

        now = datetime.utcnow().isoformat()
        relevant_count = 0
        for doc in new_docs:
            relevance = judgment_map.get(doc["id"], 0)
            if relevance > 0:
                relevant_count += 1
            seen_ids.add(doc["id"])
            all_interactions.append(
                {
                    "user_id":      user["user_id"],
                    "iteration":    iteration,
                    "query":        current_query,
                    "doc_id":       doc["id"],
                    "doc_text":     doc["text"],
                    "relevance":    relevance,
                    "goal_progress": decision.get("goal_progress", "none"),
                    "next_query":   decision.get("next_query", ""),
                    "created_at":   now,
                }
            )

        history.append({"query": current_query, "relevant_count": relevant_count})

        if decision.get("stop") or decision.get("goal_progress") == "complete":
            print(
                f"  [{user['user_id']}] Goal {decision.get('goal_progress')} — stopped. "
                f"{decision.get('reasoning', '')[:100]}"
            )
            break

        current_query = decision.get("next_query", current_query)

    print(
        f"  [{user['user_id']}] Done. "
        f"{len(all_interactions)} interactions, "
        f"{sum(1 for i in all_interactions if i['relevance'] > 0)} relevant."
    )
    return all_interactions
