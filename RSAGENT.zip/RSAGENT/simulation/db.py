import json
import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime

DEFAULT_PATH = os.path.join(os.path.dirname(__file__), "..", "simulation.db")


@contextmanager
def _conn(db_path: str):
    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row
    try:
        yield con
        con.commit()
    finally:
        con.close()


def init_db(db_path: str = DEFAULT_PATH) -> None:
    with _conn(db_path) as con:
        con.executescript("""
            CREATE TABLE IF NOT EXISTS virtual_users (
                user_id          TEXT PRIMARY KEY,
                role             TEXT NOT NULL,
                goal             TEXT NOT NULL,
                plan             TEXT NOT NULL,
                expertise_level  TEXT NOT NULL,
                starting_query   TEXT NOT NULL,
                created_at       TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS interactions (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id        TEXT    NOT NULL,
                iteration      INTEGER NOT NULL,
                query          TEXT    NOT NULL,
                doc_id         TEXT    NOT NULL,
                doc_text       TEXT    NOT NULL,
                relevance      INTEGER NOT NULL,
                goal_progress  TEXT    NOT NULL,
                next_query     TEXT,
                created_at     TEXT    NOT NULL,
                FOREIGN KEY (user_id) REFERENCES virtual_users(user_id)
            );
        """)


def insert_user(user: dict, db_path: str = DEFAULT_PATH) -> None:
    with _conn(db_path) as con:
        con.execute(
            """INSERT OR REPLACE INTO virtual_users
               (user_id, role, goal, plan, expertise_level, starting_query, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                user["user_id"],
                user["role"],
                user["goal"],
                json.dumps(user["plan"], ensure_ascii=False),
                user["expertise_level"],
                user["starting_query"],
                datetime.utcnow().isoformat(),
            ),
        )


def insert_interactions(rows: list[dict], db_path: str = DEFAULT_PATH) -> None:
    with _conn(db_path) as con:
        con.executemany(
            """INSERT INTO interactions
               (user_id, iteration, query, doc_id, doc_text, relevance,
                goal_progress, next_query, created_at)
               VALUES (:user_id, :iteration, :query, :doc_id, :doc_text,
                       :relevance, :goal_progress, :next_query, :created_at)""",
            rows,
        )


def fetch_all_users(db_path: str = DEFAULT_PATH) -> list[dict]:
    with _conn(db_path) as con:
        rows = con.execute(
            "SELECT * FROM virtual_users ORDER BY created_at"
        ).fetchall()
    users = [dict(r) for r in rows]
    for u in users:
        u["plan"] = json.loads(u["plan"])
    return users


def fetch_user_interactions(user_id: str, db_path: str = DEFAULT_PATH) -> list[dict]:
    with _conn(db_path) as con:
        rows = con.execute(
            "SELECT * FROM interactions WHERE user_id = ? ORDER BY iteration, id",
            (user_id,),
        ).fetchall()
    return [dict(r) for r in rows]
