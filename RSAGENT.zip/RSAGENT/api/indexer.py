import json
import os

import faiss
import numpy as np
import pandas as pd
from sentence_transformers import SentenceTransformer

import db
from config import settings

_model: SentenceTransformer | None = None
_index: faiss.Index | None = None
_corpus_ids: list[str] = []


def _load_model() -> None:
    global _model
    if _model is None:
        _model = SentenceTransformer(settings.model_name)
        _model.eval()


def _embed(texts: list[str]) -> np.ndarray:
    assert _model is not None
    vecs = _model.encode(
        texts,
        convert_to_numpy=True,
        batch_size=settings.batch_size,
        show_progress_bar=True,
    )
    return np.array(vecs, dtype="float32")


def is_index_ready() -> bool:
    return (
        os.path.exists(settings.faiss_index_path)
        and os.path.exists(settings.corpus_ids_path)
        and os.path.exists(settings.db_path)
    )


def build_index() -> None:
    """Load corpus TSV → SQLite + bi-encoder embeddings → FAISS Flat index."""
    global _index, _corpus_ids

    if not os.path.exists(settings.corpus_path):
        raise FileNotFoundError(
            f"Corpus not found at '{settings.corpus_path}'. "
            "Set CORPUS_PATH env var or place the file there."
        )

    _load_model()

    df = pd.read_csv(
        settings.corpus_path, sep="\t", header=None, names=["id", "text"]
    )
    df["id"] = df["id"].astype(str).str.replace(" ", "_")

    db.init_db()
    db.insert_corpus(list(zip(df["id"].tolist(), df["text"].tolist())))

    embeddings = _embed(df["text"].tolist())
    faiss.normalize_L2(embeddings)

    dim = embeddings.shape[1]
    index = faiss.IndexFlatIP(dim)
    index.add(embeddings)
    faiss.write_index(index, settings.faiss_index_path)

    _corpus_ids = df["id"].tolist()
    with open(settings.corpus_ids_path, "w", encoding="utf-8") as f:
        json.dump(_corpus_ids, f)

    _index = index
    print(f"Index built: {index.ntotal} vectors, dim={dim}")


def load_index() -> None:
    """Load FAISS index and ID list from disk."""
    global _index, _corpus_ids

    _load_model()
    _index = faiss.read_index(settings.faiss_index_path)
    with open(settings.corpus_ids_path, encoding="utf-8") as f:
        _corpus_ids = json.load(f)

    print(f"Index loaded: {_index.ntotal} vectors")


def search(query: str, top_k: int) -> list[dict]:
    """Embed query, search FAISS, fetch texts from DB, return ranked results."""
    assert _index is not None, "Index not loaded"

    q_emb = _embed([query])
    faiss.normalize_L2(q_emb)

    scores, indices = _index.search(q_emb, top_k)

    # Filter out the -1 sentinel FAISS uses for unfilled slots
    valid = [(int(idx), float(score)) for idx, score in zip(indices[0], scores[0]) if idx >= 0]
    result_ids = [_corpus_ids[idx] for idx, _ in valid]

    docs = db.fetch_by_ids(result_ids)
    text_map = {d["id"]: d["text"] for d in docs}

    return [
        {
            "rank": rank,
            "id": rid,
            "score": score,
            "text": text_map.get(rid, ""),
        }
        for rank, (rid, (_, score)) in enumerate(zip(result_ids, valid), start=1)
    ]


def index_size() -> int:
    return _index.ntotal if _index is not None else 0
