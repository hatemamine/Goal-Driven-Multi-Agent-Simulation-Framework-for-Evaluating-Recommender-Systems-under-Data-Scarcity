import sqlite3
from contextlib import contextmanager

from config import settings


@contextmanager
def _conn():
    con = sqlite3.connect(settings.db_path)
    try:
        yield con
        con.commit()
    finally:
        con.close()


def init_db() -> None:
    with _conn() as con:
        con.execute(
            "CREATE TABLE IF NOT EXISTS corpus (id TEXT PRIMARY KEY, text TEXT NOT NULL)"
        )


def insert_corpus(rows: list[tuple[str, str]]) -> None:
    with _conn() as con:
        con.executemany("INSERT OR REPLACE INTO corpus (id, text) VALUES (?, ?)", rows)


def fetch_by_ids(ids: list[str]) -> list[dict]:
    if not ids:
        return []
    with _conn() as con:
        placeholders = ",".join("?" * len(ids))
        rows = con.execute(
            f"SELECT id, text FROM corpus WHERE id IN ({placeholders})", ids
        ).fetchall()
    return [{"id": r[0], "text": r[1]} for r in rows]
