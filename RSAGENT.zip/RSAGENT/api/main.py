from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel

import indexer
from config import settings


@asynccontextmanager
async def lifespan(app: FastAPI):
    if indexer.is_index_ready():
        print("Existing index found — loading from disk.")
        indexer.load_index()
    else:
        print("No index found — building from corpus (this may take a while).")
        indexer.build_index()
    yield


app = FastAPI(title="STCALIR IR API", version="1.0.0", lifespan=lifespan)


# ── Response models ──────────────────────────────────────────────────────────

class Document(BaseModel):
    rank: int
    id: str
    score: float
    text: str


class SearchResponse(BaseModel):
    query: str
    top_k: int
    results: list[Document]


class HealthResponse(BaseModel):
    status: str
    model: str
    index_size: int


# ── Endpoints ────────────────────────────────────────────────────────────────

@app.get("/search", response_model=SearchResponse)
def search(
    query: str = Query(..., min_length=1, description="User query"),
    top_k: int = Query(default=settings.default_top_k, ge=1, le=1000, description="Number of documents to return"),
):
    try:
        results = indexer.search(query, top_k)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))
    return SearchResponse(query=query, top_k=top_k, results=results)


@app.post("/rebuild")
def rebuild():
    """Drop and rebuild the FAISS index + DB from the corpus file."""
    try:
        indexer.build_index()
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))
    return {"status": "rebuilt", "index_size": indexer.index_size()}


@app.get("/health", response_model=HealthResponse)
def health():
    return HealthResponse(
        status="ok",
        model=settings.model_name,
        index_size=indexer.index_size(),
    )
