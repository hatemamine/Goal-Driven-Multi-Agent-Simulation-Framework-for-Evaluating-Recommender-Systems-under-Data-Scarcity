import os
from dataclasses import dataclass, field


@dataclass
class Settings:
    model_name: str = field(
        default_factory=lambda: os.getenv(
            "BIENCODER_MODEL",
            "hatemestinbejaia/mmarco-Arabic-AraDPR-bi-encoder-KD-v1",
        )
    )
    corpus_path: str = field(
        default_factory=lambda: os.getenv("CORPUS_PATH", "STCALIR_collection.tsv")
    )
    faiss_index_path: str = field(
        default_factory=lambda: os.getenv("FAISS_INDEX_PATH", "stcalir.index")
    )
    corpus_ids_path: str = field(
        default_factory=lambda: os.getenv("CORPUS_IDS_PATH", "stcalir.ids.json")
    )
    db_path: str = field(
        default_factory=lambda: os.getenv("DB_PATH", "corpus.db")
    )
    default_top_k: int = field(
        default_factory=lambda: int(os.getenv("DEFAULT_TOP_K", "10"))
    )
    batch_size: int = field(
        default_factory=lambda: int(os.getenv("BATCH_SIZE", "128"))
    )


settings = Settings()
