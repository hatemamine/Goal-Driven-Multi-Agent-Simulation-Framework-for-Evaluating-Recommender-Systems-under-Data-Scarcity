"""
Shared wrapper around Gemma 4 served via the HuggingFace Inference API.

Required env vars:
  HF_TOKEN   — your HuggingFace access token (or run huggingface_hub.login() once)
  HF_MODEL   — model ID on HF Hub (default: google/gemma-4-9b-it)
"""

import json
import os
import re

from huggingface_hub import InferenceClient

MODEL = os.getenv("HF_MODEL", "google/gemma-4-9b-it")

_client: InferenceClient | None = None


def _get_client() -> InferenceClient:
    global _client
    if _client is None:
        _client = InferenceClient(
            model=MODEL,
            token=os.environ.get("HF_TOKEN"),  # falls back to cached login token
        )
    return _client


def _schema_to_hint(schema: dict) -> str:
    """Convert a JSON Schema to a compact, model-readable structure hint."""
    props = schema.get("properties", {})
    lines = []
    for name, spec in props.items():
        t = spec.get("type", "string")
        desc = spec.get("description", "")
        if "enum" in spec:
            lines.append(f'  "{name}": one of {spec["enum"]}  // {desc}')
        elif t == "array":
            item_t = spec.get("items", {}).get("type", "object")
            lines.append(f'  "{name}": [{item_t}, ...]  // {desc}')
        else:
            lines.append(f'  "{name}": {t}  // {desc}')
    return "{\n" + ",\n".join(lines) + "\n}"


def _extract_json(text: str) -> dict:
    text = text.strip()
    # 1) direct parse
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    # 2) markdown code block  ```json ... ```
    m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(1))
        except json.JSONDecodeError:
            pass
    # 3) first raw JSON object in the text
    m = re.search(r"\{.*\}", text, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(0))
        except json.JSONDecodeError:
            pass
    raise ValueError(f"Could not parse JSON from model output:\n{text[:400]}")


def generate(prompt: str, schema: dict) -> dict:
    """
    Call Gemma 4 on HuggingFace Inference API and return a dict matching `schema`.

    The schema structure is appended to the prompt so the model knows what
    fields to output. Handles markdown-wrapped and bare JSON responses.
    """
    hint = _schema_to_hint(schema)
    full_prompt = (
        f"{prompt}\n\n"
        f"Respond with a valid JSON object only — no explanation, no markdown — "
        f"matching this exact structure:\n{hint}"
    )

    response = _get_client().chat_completion(
        messages=[{"role": "user", "content": full_prompt}],
        max_tokens=1024,
    )
    text = response.choices[0].message.content
    return _extract_json(text)
