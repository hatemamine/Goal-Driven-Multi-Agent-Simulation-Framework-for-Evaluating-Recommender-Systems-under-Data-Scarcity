import faiss
import numpy as np
from sentence_transformers import SentenceTransformer


def build_profile(
    interactions: list[dict],
    model: SentenceTransformer,
    min_relevance: int = 1,
    batch_size: int = 64,
) -> np.ndarray | None:
    """
    Compute a weighted mean embedding of docs the user found relevant.

    Weight = relevance score (1 or 2), so highly-relevant docs pull harder.
    Returns a L2-normalised float32 vector, or None if no relevant docs exist.
    """
    liked = [(i["doc_text"], i["relevance"]) for i in interactions if i["relevance"] >= min_relevance]
    if not liked:
        return None

    texts, weights = zip(*liked)
    embeddings = model.encode(
        list(texts),
        convert_to_numpy=True,
        batch_size=batch_size,
        show_progress_bar=False,
    ).astype("float32")

    w = np.array(weights, dtype="float32").reshape(-1, 1)
    profile = (embeddings * w).sum(axis=0, keepdims=True) / w.sum()

    faiss.normalize_L2(profile)
    return profile[0]
