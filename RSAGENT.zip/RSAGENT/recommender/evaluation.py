"""
Evaluation pipeline using a local Gemma model for LLM-as-judge.

For each virtual user:
  1. 80 / 20 temporal split of their interaction log.
  2. Build profile from the train split.
  3. Generate top-K recommendations.
  4. Score:
       - Recall@K    : fraction of held-out liked docs that appear in top-K recs.
       - Precision@K : fraction of top-K recs judged relevant (held-out OR Gemma-judged).
       - NDCG@K      : normalised discounted cumulative gain using those relevance scores.
"""

import math
import os
import sys
from typing import Callable

import faiss
import numpy as np
from sentence_transformers import SentenceTransformer

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from llm import generate
from recommender.recommender import recommend

_JUDGE_SCHEMA = {
    "type": "object",
    "properties": {
        "relevance": {
            "type": "integer",
            "description": "0=not relevant, 1=somewhat relevant, 2=highly relevant",
        },
        "reason": {"type": "string"},
    },
    "required": ["relevance", "reason"],
}


def _llm_judge(user: dict, doc_text: str) -> int:
    prompt = (
        f"قيّم مدى ملاءمة الوثيقة التالية لهدف المستخدم.\n\n"
        f"الهوية: {user['role']}\n"
        f"الهدف: {user['goal']}\n\n"
        f"الوثيقة:\n{doc_text[:600]}\n\n"
        "أجب بـ relevance: 0 (غير ملائمة)، 1 (ملائمة نوعاً ما)، أو 2 (ملائمة جداً)."
    )
    result = generate(prompt, _JUDGE_SCHEMA)
    return max(0, min(2, int(result.get("relevance", 0))))


# ── Metric helpers ────────────────────────────────────────────────────────────

def _dcg(rels: list[float], k: int) -> float:
    return sum(r / math.log2(i + 2) for i, r in enumerate(rels[:k]))


def _ndcg(rels: list[float], k: int) -> float:
    ideal = _dcg(sorted(rels, reverse=True), k)
    return _dcg(rels, k) / ideal if ideal > 0 else 0.0


def _precision(rels: list[float], k: int) -> float:
    return sum(1 for r in rels[:k] if r > 0) / k


def _recall(rels: list[float], n_relevant: int, k: int) -> float:
    if n_relevant == 0:
        return 0.0
    return sum(1 for r in rels[:k] if r > 0) / n_relevant


# ── Per-user evaluation ───────────────────────────────────────────────────────

def evaluate_user(
    user: dict,
    interactions: list[dict],
    model: SentenceTransformer,
    index: faiss.Index,
    corpus_ids: list[str],
    fetch_text: Callable[[str], str | None],
    k: int = 10,
    train_ratio: float = 0.8,
) -> dict:
    split = max(1, int(len(interactions) * train_ratio))
    train, test = interactions[:split], interactions[split:]

    test_liked_ids = {i["doc_id"] for i in test if i["relevance"] > 0}

    recs = recommend(train, model, index, corpus_ids, top_k=k, search_k=k * 50)

    relevances: list[float] = []
    for rec in recs:
        if rec["doc_id"] in test_liked_ids:
            relevances.append(2.0)
        else:
            text = fetch_text(rec["doc_id"])
            score = _llm_judge(user, text) if text else 0
            relevances.append(float(score))

    return {
        "user_id":        user["user_id"],
        "role":           user["role"],
        "ndcg_at_k":      _ndcg(relevances, k),
        "precision_at_k": _precision(relevances, k),
        "recall_at_k":    _recall(relevances, len(test_liked_ids), k),
        "k":              k,
        "n_train":        len(train),
        "n_test_liked":   len(test_liked_ids),
        "n_recs":         len(recs),
        "relevances":     relevances,
    }


# ── Full evaluation loop ──────────────────────────────────────────────────────

def evaluate_all(
    users: list[dict],
    get_interactions: Callable[[str], list[dict]],
    model: SentenceTransformer,
    index: faiss.Index,
    corpus_ids: list[str],
    fetch_text: Callable[[str], str | None],
    k: int = 10,
    min_interactions: int = 5,
) -> list[dict]:
    results = []
    for user in users:
        interactions = get_interactions(user["user_id"])
        if len(interactions) < min_interactions:
            print(f"[{user['user_id']}] Too few interactions ({len(interactions)}) — skipping.")
            continue
        print(f"[{user['user_id']}] Evaluating ({len(interactions)} interactions)...")
        metrics = evaluate_user(
            user, interactions, model, index, corpus_ids, fetch_text, k=k
        )
        results.append(metrics)
        print(
            f"  NDCG@{k}={metrics['ndcg_at_k']:.3f}  "
            f"P@{k}={metrics['precision_at_k']:.3f}  "
            f"R@{k}={metrics['recall_at_k']:.3f}"
        )
    return results


def aggregate(results: list[dict]) -> dict:
    if not results:
        return {}
    keys = ["ndcg_at_k", "precision_at_k", "recall_at_k"]
    return {
        f"mean_{key}": float(np.mean([r[key] for r in results]))
        for key in keys
    } | {"n_users": len(results), "k": results[0]["k"]}
