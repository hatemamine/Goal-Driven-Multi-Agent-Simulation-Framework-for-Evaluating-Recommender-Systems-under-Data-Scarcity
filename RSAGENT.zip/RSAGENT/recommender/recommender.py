import faiss
import numpy as np
from sentence_transformers import SentenceTransformer

from recommender.profile_builder import build_profile


def recommend(
    interactions: list[dict],
    model: SentenceTransformer,
    index: faiss.Index,
    corpus_ids: list[str],
    top_k: int = 10,
    search_k: int = 500,
) -> list[dict]:
    """
    Build a user profile from interactions and return top_k unseen recommended docs.

    - interactions : full list of (doc_id, doc_text, relevance, ...) dicts
    - model        : the bi-encoder used to embed the corpus
    - index        : the loaded FAISS IndexFlatIP
    - corpus_ids   : list of string doc IDs parallel to the FAISS index
    - top_k        : number of recommendations to return
    - search_k     : how many candidates to pull from FAISS before filtering seen docs
                     (must be >= top_k + len(seen_ids) in the worst case)
    """
    profile = build_profile(interactions, model)
    if profile is None:
        return []

    seen_ids = {i["doc_id"] for i in interactions}

    q = profile.reshape(1, -1).copy()
    faiss.normalize_L2(q)
    scores, indices = index.search(q, search_k)

    results = []
    for idx, score in zip(indices[0], scores[0]):
        if idx < 0:
            continue
        doc_id = corpus_ids[idx]
        if doc_id in seen_ids:
            continue
        results.append({"doc_id": doc_id, "score": float(score), "faiss_idx": int(idx)})
        if len(results) >= top_k:
            break

    return results
